<?php
$Host = "localhost";
$User = "root";
$Password = "";
$Db = "my_db";
$password = "1111";
$login = "Alex";
?>